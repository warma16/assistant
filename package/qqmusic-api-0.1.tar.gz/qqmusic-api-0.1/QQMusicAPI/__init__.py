# coding=utf-8
from .pager import *
from .qqmusic import *
from .singer import *
from .song import *
